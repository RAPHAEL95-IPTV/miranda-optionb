// drone robot placeholder
