// rover robot definition placeholder
