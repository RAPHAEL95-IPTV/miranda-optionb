// Placeholder for Scratch 3.0 extension bridge (would connect via WebSocket)
// Full Scratch extension requires packaging; here we provide a stub to show integration path.
console.log("scratch-bridge loaded");
